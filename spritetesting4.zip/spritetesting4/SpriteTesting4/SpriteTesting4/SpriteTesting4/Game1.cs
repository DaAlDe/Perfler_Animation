using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SpriteTesting4
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D t2dPrincess;
        MobileSprite myPrincess;
        Vector2 prinzessinposi = new Vector2(100, 100);

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {            
            this.IsMouseVisible = true;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            t2dPrincess = Content.Load<Texture2D>(@"Textures\PrincessCharacter");

            myPrincess = new MobileSprite(t2dPrincess);
            myPrincess.Sprite.AddAnimation("leftstop", 0, 0, 32, 64, 1, 0.1f);
            myPrincess.Sprite.AddAnimation("left", 0, 0, 32, 64, 4, 0.1f);
            myPrincess.Sprite.AddAnimation("rightstop", 0, 64, 32, 64, 1, 0.1f);
            myPrincess.Sprite.AddAnimation("right", 0, 64, 32, 64, 4, 0.1f);
            myPrincess.Sprite.CurrentAnimation = "rightstop";
            myPrincess.Position = new Vector2(100, 300);

        }

        protected override void UnloadContent()
        {
            
        }

        protected override void Update(GameTime gameTime)
        {
            KeyboardState ks = Keyboard.GetState();

            // fenster schliessen
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            //MouseState ms = Mouse.GetState();

            bool leftkey = ks.IsKeyDown(Keys.Left);
            bool rightkey = ks.IsKeyDown(Keys.Right);

            if (leftkey)
            {
                if (myPrincess.Sprite.CurrentAnimation != "left")
                {
                    myPrincess.Sprite.CurrentAnimation = "left";
                }
                myPrincess.Sprite.MoveBy(-2, 0);
            }

            if (rightkey)
            {
                if (myPrincess.Sprite.CurrentAnimation != "right")
                {
                    myPrincess.Sprite.CurrentAnimation = "right";
                }
                myPrincess.Sprite.MoveBy(2, 0);
            }

            if (!leftkey && !rightkey)
            {
                if (myPrincess.Sprite.CurrentAnimation == "left")
                {
                    myPrincess.Sprite.CurrentAnimation = "leftstop";
                }
                if (myPrincess.Sprite.CurrentAnimation == "right")
                {
                    myPrincess.Sprite.CurrentAnimation = "rightstop";
                }
            }

            myPrincess.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            myPrincess.Draw(spriteBatch);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}



