﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SpriteTesting4
{
    class MobileSprite
    {
        // Spriteanimations objekt welches die grafischen und animations Daten enthält
        SpriteAnimation asSprite;
        // 2 integers zur kollisionserkennung mithilfe der "bounding-box"
        int iCollisionBufferX = 0;
        int iCollisionBufferY = 0;
        // Status des Sprite feststellen.
        bool bActive = true;
        // Wenn true wird der Sprite auch gezeichnet
        bool bVisible = true;

        Texture2D texture;
        Vector2 position;
        public Vector2 velocity;
        public bool hasJumped;
        public Rectangle rectangle;

        public SpriteAnimation Sprite
        {
            get { return asSprite; }
        }

         public MobileSprite(Texture2D newTexture, Vector2 newPosition)
        {
            texture = newTexture;
            position = newPosition;
            hasJumped = true;            
        }

        public Vector2 Position
        {
            get { return asSprite.Position; }
            set { asSprite.Position = value; }
        }


        public int HorizontalCollisionBuffer
        {
            get { return iCollisionBufferX; }
            set { iCollisionBufferX = value; }
        }

        public int VerticalCollisionBuffer
        {
            get { return iCollisionBufferY; }
            set { iCollisionBufferY = value; }
        }


        public bool IsVisible
        {
            get { return bVisible; }
            set { bVisible = value; }
        }

        public bool IsActive
        {
            get { return bActive; }
            set { bActive = value; }
        }


        public Rectangle BoundingBox
        {
            get { return asSprite.BoundingBox; }
        }

        public Rectangle CollisionBox
        {
            get
            {
                return new Rectangle(
                    asSprite.BoundingBox.X + iCollisionBufferX,
                    asSprite.BoundingBox.Y + iCollisionBufferY,
                    asSprite.Width - (2 * iCollisionBufferX),
                    asSprite.Height - (2 * iCollisionBufferY));
            }
        }

        public MobileSprite(Texture2D texture)
        {
            asSprite = new SpriteAnimation(texture);
        }

        public void Update(GameTime gameTime)
        {
           
            if (bActive)
                asSprite.Update(gameTime);

            position += velocity;
            rectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width, texture.Height);


            if (Keyboard.GetState().IsKeyDown(Keys.Right)) velocity.X = 3f;
            else if (Keyboard.GetState().IsKeyDown(Keys.Left)) velocity.X = -3f; else velocity.X = 0f;

            if (Keyboard.GetState().IsKeyDown(Keys.Space) && hasJumped == false)
            {
                position.Y -= 10f;
                velocity.Y = -5f;
                hasJumped = true;
            }

            float i = 1;
            velocity.Y += 0.15f * i;

            
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectangle, Color.White);

            if (bVisible)
            {
                asSprite.Draw(spriteBatch, 0, 0);
            }
        }
    }
}
