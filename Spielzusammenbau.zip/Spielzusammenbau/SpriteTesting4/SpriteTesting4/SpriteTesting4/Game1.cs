using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SpriteTesting4
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D t2dPrincess;
        MobileSprite myPrincess;
        Vector2 prinzessinposi = new Vector2(100, 100);

        List<Platform> platforms = new List<Platform>();

       /* Vector2 position;
        public Vector2 velocity;
        public bool hasJumped;
        public Rectangle rectangle;
        Texture2D texture; */

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {            
            this.IsMouseVisible = true;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            t2dPrincess = Content.Load<Texture2D>(@"Textures\PrincessCharacter");

            myPrincess = new MobileSprite(t2dPrincess);
            myPrincess.Sprite.AddAnimation("leftstop", 0, 0, 32, 64, 1, 0.1f);
            myPrincess.Sprite.AddAnimation("left", 0, 0, 32, 64, 4, 0.1f);
            myPrincess.Sprite.AddAnimation("rightstop", 0, 64, 32, 64, 1, 0.1f);
            myPrincess.Sprite.AddAnimation("right", 0, 64, 32, 64, 4, 0.1f);
            myPrincess.Sprite.CurrentAnimation = "rightstop";
            myPrincess.Position = new Vector2(100, 300);

            platforms.Add(new Platform(Content.Load<Texture2D>("Platform"), new Vector2(30, 400)));
            platforms.Add(new Platform(Content.Load<Texture2D>("Platform"), new Vector2(350, 300)));
            platforms.Add(new Platform(Content.Load<Texture2D>("Platform"), new Vector2(700, 350)));


        }

        protected override void UnloadContent()
        {
            
        }

        protected override void Update(GameTime gameTime)
        {
            KeyboardState ks = Keyboard.GetState();
            IsMouseVisible = true;

           // position += velocity;
           // rectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width, texture.Height);

            // fenster schliessen
            if (Keyboard.GetState().IsKeyDown(Keys.Escape)) Exit();

            //MouseState ms = Mouse.GetState();

            bool leftkey = ks.IsKeyDown(Keys.Left);
            bool rightkey = ks.IsKeyDown(Keys.Right);

            if (leftkey)
            {
                if (myPrincess.Sprite.CurrentAnimation != "left")
                {
                    myPrincess.Sprite.CurrentAnimation = "left";
                }
                myPrincess.Sprite.MoveBy(-2, 0);
            }

            if (rightkey)
            {
                if (myPrincess.Sprite.CurrentAnimation != "right")
                {
                    myPrincess.Sprite.CurrentAnimation = "right";
                }
                myPrincess.Sprite.MoveBy(2, 0);
            }

            if (!leftkey && !rightkey)
            {
                if (myPrincess.Sprite.CurrentAnimation == "left")
                {
                    myPrincess.Sprite.CurrentAnimation = "leftstop";
                }
                if (myPrincess.Sprite.CurrentAnimation == "right")
                {
                    myPrincess.Sprite.CurrentAnimation = "rightstop";
                }
            }

          /*  if (Keyboard.GetState().IsKeyDown(Keys.Right)) velocity.X = 3f;
            else if (Keyboard.GetState().IsKeyDown(Keys.Left)) velocity.X = -3f; else velocity.X = 0f;

            if (Keyboard.GetState().IsKeyDown(Keys.Space) && hasJumped == false)
            {
                position.Y -= 10f;
                velocity.Y = -5f;
                hasJumped = true;
            }

            float i = 1;
            velocity.Y += 0.15f * i; */

            foreach (Platform platform in platforms)
                if (myPrincess.rectangle.isOnTopOf(platform.rectangle))
                {
                    myPrincess.velocity.Y = 0f;
                    myPrincess.hasJumped = false;
                }

            myPrincess.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);


           // spriteBatch.Draw(texture, rectangle, Color.White);

            spriteBatch.Begin();
            foreach (Platform platform in platforms)
                platform.Draw(spriteBatch);
            myPrincess.Draw(spriteBatch);
            //player.Draw(spriteBatch);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}

static class RectangleHelper
{
    const int penetrationMargin = 5;
    public static bool isOnTopOf(this Rectangle r1, Rectangle r2)
    {
        return (r1.Bottom >= r2.Top - penetrationMargin &&
            r1.Bottom <= r2.Top + 1 &&
            r1.Right >= r2.Left + 5 &&
            r1.Left <= r2.Right - 5);
    }
}



